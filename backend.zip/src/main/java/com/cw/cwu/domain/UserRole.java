package com.cw.cwu.domain;

public enum UserRole {
    STUDENT, PROFESSOR, ADMIN
}
package com.cw.cwu.domain;

public enum ScheduleType {
    ENROLL,
    CLASS,
    GRADE
}

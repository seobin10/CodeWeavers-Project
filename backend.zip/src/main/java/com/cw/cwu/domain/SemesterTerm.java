package com.cw.cwu.domain;

public enum SemesterTerm {
    FIRST,
    SECOND
}
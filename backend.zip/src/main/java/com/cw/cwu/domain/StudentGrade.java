package com.cw.cwu.domain;

public enum StudentGrade {
    A_PLUS, A0, B_PLUS, B0, C_PLUS, C0, D_PLUS, D0, F
}

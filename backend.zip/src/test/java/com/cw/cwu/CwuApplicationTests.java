package com.cw.cwu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CwuApplicationTests {

	@Test
	void contextLoads() {
	}

}

import RegisterComponent from "../../components/users/RegisterComponent";

function RegisterPage() {
  return <RegisterComponent />;
}

export default RegisterPage;

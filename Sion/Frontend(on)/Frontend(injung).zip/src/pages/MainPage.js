import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { getAuthHeader } from "../util/authHeader";

const images = [
  "/images/Eon1.jpg",
  "/images/Eon3.jpg",
  "/images/Eon4.jpg",
  "/images/Eon6.jpg",
  "/images/Eon7.jpg",
];

const MainPage = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [noticeList, setNoticeList] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const navigate = useNavigate();

  const calender = [
    { date: "2025-03-02", event: "개강" },
    { date: "2025-03-05", event: "수강신청 마감" },
    { date: "2025-03-15", event: "수업 취소 마감" },
  ];

  useEffect(() => {
    const fetchNotices = async () => {
      try {
        const res = await axios.get(
          "http://localhost:8080/api/notice/list",
          getAuthHeader()
        );
        const sorted = res.data.sort(
          (a, b) => new Date(b.noticeDate) - new Date(a.noticeDate)
        );
        setNoticeList(sorted.slice(0, 6));
      } catch (err) {
        console.error("공지사항 불러오기 실패", err);
      }
    };
    fetchNotices();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleSearchKeyDown = (e) => {
    if (e.key === "Enter" && searchTerm.trim()) {
      navigate("/main/noticelist", {
        state: { keyword: searchTerm.trim() },
      });
    }
  };

  const handleTagClick = (tag) => {
    const keyword = tag.replace(/^#/, "");
    navigate("/main/noticelist", {
      state: { keyword },
    });
  };

  return (
    <div className="max-h-full">
      {/* 전체 너비 홍보 이미지 */}
      <div className="mt-0 mb-10">
        <img
          src={images[currentIndex]}
          alt="홍보 이미지"
          className="w-full h-[370px] object-cover block"
        />
      </div>
      <div className="w-full">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {/* 좌우 콘텐츠 */}
        </div>
      </div>
      {/* 나머지 콘텐츠는 중앙 정렬 */}
      <div className="max-w-screen-xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div className="flex flex-col space-y-8">
            <div className="space-y-10">
              <h1 className="text-8xl font-bold mb-10">
                <ul>
                  <li>Open</li>
                  <li>Your future</li>
                </ul>
              </h1>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={handleSearchKeyDown}
                placeholder="검색어를 입력해주세요 "
                className="w-full border-b-2 border-black p-2 text-lg focus:outline-none"
              />
              <div className="flex flex-wrap gap-2 text-sm text-gray-600">
                {["#휴학", "#복학", "#수강신청", "#성적조회", "#강의평가"].map(
                  (tag, idx) => (
                    <span
                      key={idx}
                      className="bg-gray-100 px-2 py-1 rounded hover:bg-gray-300 cursor-pointer"
                      onClick={() => handleTagClick(tag)}
                    >
                      {tag}
                    </span>
                  )
                )}
              </div>
            </div>

            {/* 공지사항 요약 */}
            <div className="pt-6">
              <div className="flex justify-between items-center space-y-6 mt-4 mb-6">
                <h2 className="text-2xl font-semibold">📢 공지사항</h2>
                <Link
                  to="/main/noticelist"
                  className="text-blue-500 text-sm hover:underline"
                >
                  전체보기
                </Link>
              </div>
              <ul className="space-y-2 text-sm">
                {noticeList.map((n, idx) => (
                  <li key={idx} className="flex justify-between text-gray-800">
                    <Link
                      to="/main/noticedata"
                      state={{ noticeId: n.noticeId }}
                      className="hover:underline"
                    >
                      {n.title}
                    </Link>
                    <span>{n.noticeDate?.slice(5, 10)}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* 우측 (달력형 학사일정) */}
          <div className="flex flex-col space-y-6 mt-14">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold mb-4">📅 학사일정</h2>
              <Link
                to="/main/calender"
                className="text-sm text-blue-500 hover:underline"
              >
                전체보기
              </Link>
            </div>
            <div className="grid grid-cols-7 gap-1 text-xs text-center border p-3 rounded">
              {["일", "월", "화", "수", "목", "금", "토"].map((d, idx) => (
                <div key={idx} className="font-bold text-gray-700">
                  {d}
                </div>
              ))}
              {Array.from({ length: 31 }).map((_, day) => {
                const dateStr = `2025-03-${String(day + 1).padStart(2, "0")}`;
                const match = calender.find((c) => c.date === dateStr);
                return (
                  <div
                    key={day}
                    className={`h-24 border text-[10px] p-1 ${
                      match ? "bg-yellow-100 font-bold" : ""
                    }`}
                  >
                    <div>{day + 1}</div>
                    {match && <div>{match.event}</div>}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MainPage;

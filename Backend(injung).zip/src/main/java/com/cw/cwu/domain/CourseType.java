package com.cw.cwu.domain;

public enum CourseType {
    MAJOR, LIBERAL
}

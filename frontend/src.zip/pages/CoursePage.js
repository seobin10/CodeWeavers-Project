import React from "react";

function CoursePage() {
  return (
    <div>
      <h1>강의목록 페이지</h1>
      <p>이곳에서 강의 조회를 할 수 있습니다.</p>
    </div>
  );
}

export default CoursePage;

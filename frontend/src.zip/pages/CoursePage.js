import React from "react";

function CoursePage() {
  return (
    <div>
      <h1>수강신청 페이지</h1>
      <p>이곳에서 수강 신청을 할 수 있습니다.</p>
    </div>
  );
}

export default CoursePage;

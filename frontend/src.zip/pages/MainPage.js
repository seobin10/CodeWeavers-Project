import React from "react";

const MainPage = () => {
  return (
    <div className="text-3xl">
      <div>MainPage</div>
    </div>
  );
};

export default MainPage;

import React, { useContext, useEffect, useState, useCallback } from "react";
import { getConfirmedCourses } from "../api/enrollmentApi";
import { AuthContext } from "../App";

const days = ["월", "화", "수", "목", "금"];
const periods = Array.from({ length: 12 }, (_, i) => `${9 + i}시`);

const SchedulePage = () => {
  const { userId } = useContext(AuthContext);
  const [schedule, setSchedule] = useState([]);

  // 확정된 강의 조회
  const fetchSchedule = useCallback(async () => {
    try {
      const response = await getConfirmedCourses(userId);
      setSchedule(response.data);
    } catch (error) {
      console.error("시간표 조회 실패:", error);
    }
  }, [userId]);

  useEffect(() => {
    if (userId) fetchSchedule();
  }, [userId, fetchSchedule]);

  return (
    <div className="max-w-5xl mx-auto p-6 bg-white shadow-md mt-4 rounded-md">
      <h2 className="text-2xl font-bold text-center mb-4">내 시간표</h2>
      <div className="overflow-x-auto">
        <table className="w-full border-collapse border border-gray-300">
          <thead>
            <tr className="bg-gray-100 text-center">
              <th className="border border-gray-300 p-2">시간</th>
              {days.map((day) => (
                <th key={day} className="border border-gray-300 p-2">
                  {day}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {periods.map((time, periodIndex) => (
              <tr key={time} className="text-center h-16">
                <td className="border border-gray-300 p-2 bg-gray-200">
                  {time}
                </td>
                {days.map((day) => {
                  const course = schedule.find(
                    (c) =>
                      c.classDay === day &&
                      c.classStartPeriod <= periodIndex + 9 &&
                      c.classEndPeriod >= periodIndex + 9
                  );
                  return (
                    <td
                      key={`${day}-${time}`}
                      className="border border-gray-300 relative p-2"
                    >
                      {course ? (
                        <div className="bg-blue-200 p-2 rounded shadow-md text-sm">
                          <p className="font-bold">{course.courseName}</p>
                          <p>{course.professorName}</p>
                          <p>{course.classRoom}</p>
                        </div>
                      ) : null}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SchedulePage;

package com.cw.cwu.domain;

public enum Status {
    OPEN, ANSWERED
}
